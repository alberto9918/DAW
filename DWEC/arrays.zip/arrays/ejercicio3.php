<html>

<head>
    <title>Ejercicio 3</title>
</head>

<body>
    <?php
    $num = 3;
    $multiplo = 1;
    $max = 10;

    echo "<h1>EJERCICIO 3</h1>";
    echo "<ol>";
    for ($i = 0; $i < $max; $i++) {
        if ($multiplo % $num == 0) {
            echo "<li>".$multiplo."</li>";
            
        }  else {
            $i--;
        }
        $multiplo++;          
    }
    echo "</ol>";
    ?>

</body>

</html>