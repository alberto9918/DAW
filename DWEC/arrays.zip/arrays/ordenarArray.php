<html>

<head>
    <title>Ejercicio de Array Asociativo</title>
</head>

<body>
    <?php
        // Almacenar dicha información y visualizarla.
        $peliculas = array('El apartamento' => 1960, 'Charada' => 1963,
         'Doctor Zhivago' => 1965, 'Psicosis' => 1960, 'El apartamento' => 1960, 'La gran familia' => 1962);

        echo 'Array asociativo sin ordenar:<br><br>'; 

        foreach($peliculas as $titulo=>$year){
             echo "Título de la película:  ". $titulo."<br>";
             echo "Año de producción: ". $year ."<br><br>";
        }

        // ordenar array en orden descendente por año de producción
        
        echo "<br><br>";
        echo "Array asociativo ordenado en orden descendente por año de producción:<br><br>";

        arsort($peliculas);

        foreach($peliculas as $titulo=>$year){
            echo "Título de la película:  ". $titulo."<br>";
            echo "Año de producción: ". $year ."<br><br>";
        }

        

    ?>

</body>

</html>