<html>

<head>
    <title>Ejercicio de Array Asociativo</title>
</head>

<body>
    <?php
        // Almacenar dicha información y visualizarla.
        $peliculas = array('El apartamento' => 1960, 'Charada' => 1963,
         'Doctor Zhivago' => 1965, 'Psicosis' => 1960, 'El apartamento' => 1960, 'La gran familia' => 1962);

        foreach($peliculas as $titulo=>$year){
             echo "Título de la película:  ". $titulo."<br>";
             echo "Año de producción: ". $year ."<br><br>";
        }

        // Visualizar sólo los títulos, en formato tabla.

        /*echo "<table border=1>"; 

            foreach($peliculas as $titulo => $year){
                echo "<tr><td>". $titulo ."</td></tr>";
            }
        
        echo "</table>"; */

        $limite = sizeof($peliculas);
        reset($peliculas);

        echo "<table border=1>"; 
        
            for($i = 1; $i <= $limite; $i++) {
                echo "<tr><td>". key($peliculas) ."</td></tr>";
                next($peliculas);
            }
        
        echo "</table>";

        echo "<br><br>";
        //-----------------------------------------
        // Visualizar en formato tabla los títulos de aquellas películas posteriores a 1960.

        reset($peliculas);

        echo "<table border=1>"; 

            for($i = 1; $i <= $limite; $i++) {

                if(current($peliculas) > 1960){
                    echo "<tr><td>". key($peliculas) ."</td></tr>";
                }
                
                next($peliculas);
            }
        
        echo "</table>"; 

    ?>

</body>

</html>