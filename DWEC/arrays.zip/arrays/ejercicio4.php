<html>

<head>
    <title>Ejercicio de Array Asociativo</title>
</head>

<body>
    <?php
        // Dado el siguiente array con los datos de los empleados de una determinada empresa:
        $empleados = array(
                    array('Powell, Alfredo','Administrativo',5500),
                    array('Pérez, Verónica','Administrativo',5200),
                    array('Goldstein, Juan','Recursos Humanos',6800),
                    array('Giaccomo, Walter','Recursos Humanos',6200),
                    array('Armani, Luis','Compras',10500),
                    array('Sarlanga, Horacio','Administrativo',5500),
                    array('Juárez, Alicia','Compras',7500),
                    array('Toselli, Agustina','Mantenimiento',5800),
                    array('Gómez, Valeria','Sistemas',4700),
		            array('Valverde, Emiliano','Recursos Humanos',5800),
		            array('Domínguez, Carlos','Mantenimiento',4900),
		            array('Carranza, Saúl','Administrativo',9500),
        );

        //Se pide realizar lo siguiente, en el orden que se indica:
        
        echo "a) Visualizar en una tabla  el contenido del array. Las columnas irán etiquetadas con “NOMBRE”,
         “DIRECCIÓN”, “SUELDO”.<br><br>";
               
            echo "<table border=1>";
                echo "<tr>"."<td>NOMBRE</td>"."<td>DIRECCIÓN</td>"."<td>SUELDO</td>"."</tr>";
                for($i = 0; $i < count($empleados); $i++){
                    echo "<tr>";
                        for($j = 0; $j < count($empleados[$i]) ; $j++){
                            echo "<td>". $empleados[$i][$j] ."</td>";
                        }
                    echo "</tr>";    
                }
            echo "</table>";

        echo "<br><br>b) Obtener y mostrar el nombre del empleado que gana más dinero.<br><br>";
            
            $empleado = $empleados[0];

            for($i = 0; $i < count($empleados); $i++){
                
                if($empleados[$i][2] > $empleado[2]){
                    $empleado = $empleados[$i];
                }         

            }

            echo "El empleado que gana más dinero, con un sueldo de ". $empleado[2] . " euros, es " . $empleado[0];
            
      

    ?>

</body>

</html>